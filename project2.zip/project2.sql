--1
WITH YearlyIncome AS
(
    SELECT YEAR(i.InvoiceDate) AS InvoiceYear,SUM(il.ExtendedPrice) AS IncomePerYear,
    COUNT(DISTINCT MONTH(i.InvoiceDate)) AS NumberOfDistinctMonth
    FROM Sales.Invoices i
    INNER JOIN Sales.InvoiceLines il
    ON i.InvoiceID = il.InvoiceID
    GROUP BY YEAR(i.InvoiceDate)
),
LinearIncome 
AS(
   SELECT InvoiceYear,IncomePerYear,NumberOfDistinctMonth,IncomePerYear * 12.0 / NumberOfDistinctMonth AS YearlyLinearIncome
   FROM YearlyIncome
)
SELECT InvoiceYear,CAST(IncomePerYear AS DECIMAL(18,2)) AS IncomePerYear,
NumberOfDistinctMonth, CAST(YearlyLinearIncome AS DECIMAL(18,2)) AS YearlyLinearIncome,CAST(
( YearlyLinearIncome- LAG(YearlyLinearIncome) OVER (ORDER BY InvoiceYear) ) * 100.0 /  LAG(YearlyLinearIncome) OVER (ORDER BY InvoiceYear)
AS DECIMAL(18,2)) AS GrowthRate
FROM LinearIncome
ORDER BY InvoiceYear
--2
WITH QuarterlyCustomerIncome AS (
SELECT YEAR(i.InvoiceDate) AS TheYear,DATEPART(QUARTER, i.InvoiceDate) AS TheQuarter,c.CustomerName,
       SUM(il.ExtendedPrice) AS IncomePerQuarterYear,
       ROW_NUMBER() OVER (
       PARTITION BY YEAR(i.InvoiceDate), DATEPART(QUARTER, i.InvoiceDate) 
       ORDER BY SUM(il.ExtendedPrice) DESC
    ) AS DNR
    FROM Sales.Invoices i
    JOIN Sales.InvoiceLines il ON i.InvoiceID = il.InvoiceID
    JOIN Sales.Customers c ON i.CustomerID = c.CustomerID
    GROUP BY YEAR(i.InvoiceDate), DATEPART(QUARTER, i.InvoiceDate), c.CustomerName
)
SELECT TheYear, TheQuarter, CustomerName, IncomePerQuarterYear, DNR
FROM QuarterlyCustomerIncome
WHERE DNR <= 5
ORDER BY TheYear, TheQuarter, DNR
--3
SELECT TOP 10
    il.StockItemID,
    si.StockItemName,
    SUM(il.ExtendedPrice - il.TaxAmount) AS TotalProfit
FROM Sales.InvoiceLines il
JOIN Warehouse.StockItems si ON il.StockItemID = si.StockItemID
GROUP BY il.StockItemID, si.StockItemName
ORDER BY TotalProfit DESC
--4
SELECT ROW_NUMBER() OVER (ORDER BY (RecommendedRetailPrice - UnitPrice) DESC) AS Rn, StockItemID,
    StockItemName, UnitPrice, RecommendedRetailPrice,
    (RecommendedRetailPrice - UnitPrice) AS NominalProductProfit,
    DENSE_RANK() OVER (ORDER BY (RecommendedRetailPrice - UnitPrice) DESC) AS DNR
FROM Warehouse.StockItems
WHERE ValidTo > GETDATE()
ORDER BY NominalProductProfit DESC
--5
SELECT CAST(s.SupplierID AS VARCHAR) + ' - ' + s.SupplierName AS SupplierDetails,
STRING_AGG(CAST(si.StockItemID AS VARCHAR) + ' ' + si.StockItemName, ' /, ') AS ProductDetails
FROM Purchasing.Suppliers s
JOIN Warehouse.StockItems si ON s.SupplierID = si.SupplierID
GROUP BY s.SupplierID, s.SupplierName
--6
SELECT TOP 5c.CustomerID,ci.CityName,co.CountryName,co.Continent,co.Region,
    SUM(il.ExtendedPrice) AS TotalExtendedPrice
FROM Sales.Invoices i
JOIN Sales.InvoiceLines il ON i.InvoiceID = il.InvoiceID
JOIN Sales.Customers c ON i.CustomerID = c.CustomerID
JOIN Application.Cities ci ON c.DeliveryCityID = ci.CityID
JOIN Application.StateProvinces sp ON ci.StateProvinceID = sp.StateProvinceID
JOIN Application.Countries co ON sp.CountryID = co.CountryID
GROUP BY c.CustomerID, ci.CityName, co.CountryName, co.Continent, co.Region
ORDER BY TotalExtendedPrice DESC
--7
WITH MonthlySums 
AS (
    SELECT YEAR(i.InvoiceDate) AS InvoiceYear,MONTH(i.InvoiceDate) AS MonthNum,SUM(il.ExtendedPrice) AS MonthlyTotal
    FROM Sales.Invoices i
    JOIN Sales.InvoiceLines il ON i.InvoiceID = il.InvoiceID
    GROUP BY YEAR(i.InvoiceDate), MONTH(i.InvoiceDate)
),
CumulativeMonths 
AS (
    SELECT InvoiceYear,MonthNum,MonthlyTotal,SUM(MonthlyTotal) OVER (PARTITION BY InvoiceYear ORDER BY MonthNum) AS CumulativeTotal
    FROM MonthlySums
)
SELECT CAST(InvoiceYear AS VARCHAR(10)) AS InvoiceYear,
CASE WHEN GROUPING(MonthNum) = 1 THEN 'Grand Total' ELSE CAST(MonthNum AS VARCHAR(10)) END AS InvoiceMonth,
SUM(MonthlyTotal) AS MonthlyTotal,CASE WHEN GROUPING(MonthNum) = 1 THEN SUM(MonthlyTotal) ELSE MAX(CumulativeTotal) END AS CumulativeTotal
FROM CumulativeMonths
GROUP BY ROLLUP(InvoiceYear, MonthNum)
HAVING InvoiceYear IS NOT NULL
ORDER BY InvoiceYear, GROUPING(MonthNum), MonthNum
--8
SELECT MONTH(OrderDate) AS OrderMonth,
COUNT(CASE WHEN YEAR(OrderDate) = 2013 THEN OrderID END) AS [2013],COUNT(CASE WHEN YEAR(OrderDate) = 2014 THEN OrderID END) AS [2014],
COUNT(CASE WHEN YEAR(OrderDate) = 2015 THEN OrderID END) AS [2015],COUNT(CASE WHEN YEAR(OrderDate) = 2016 THEN OrderID END) AS [2016]
FROM Sales.Orders
GROUP BY MONTH(OrderDate)
ORDER BY OrderMonth
--9
WITH RawOrderIntervals 
AS (
    SELECT o.CustomerID,c.CustomerName,o.OrderDate,
        (
         SELECT MAX(Prev.OrderDate) 
         FROM Sales.Orders Prev 
         WHERE Prev.CustomerID = o.CustomerID AND Prev.OrderDate < o.OrderDate
        ) AS PreviousOrderDate
    FROM Sales.Orders o
    JOIN Sales.Customers c ON o.CustomerID = c.CustomerID
),
CustomerAggregates 
AS (
    SELECT CustomerID,CustomerName,OrderDate,PreviousOrderDate,
    AVG(DATEDIFF(DAY, PreviousOrderDate, OrderDate)) OVER (PARTITION BY CustomerID) AS AvgDaysBetweenOrders,
    MAX(OrderDate) OVER (PARTITION BY CustomerID) AS LastCustOrderDate,
   (SELECT MAX(OrderDate) FROM Sales.Orders) AS LasrOrderDateAll
    FROM RawOrderIntervals
)
SELECT  CustomerID, CustomerName, OrderDate,PreviousOrderDate,AvgDaysBetweenOrders, LastCustOrderDate,LasrOrderDateAll,
    DATEDIFF(DAY, LastCustOrderDate, LasrOrderDateAll) AS DaysSinceLastOrder,
    CASE 
    WHEN DATEDIFF(DAY, LastCustOrderDate, LasrOrderDateAll) > 2 * AvgDaysBetweenOrders THEN 'Churn Potential'
    ELSE 'Active'
    END AS CustomerStatus
FROM CustomerAggregates
ORDER BY CustomerID, OrderDate
--10
WITH NormalizedCustomers 
AS (
    SELECT DISTINCT
    CustomerCategoryID,
    CASE 
    WHEN CustomerName LIKE 'Wingtip%' THEN 'Wingtip Toys'
    WHEN CustomerName LIKE 'Tailspin%' THEN 'Tailspin Toys'
    ELSE CustomerName 
    END AS GenericCustomerName
    FROM Sales.Customers
),
CategoryCounts 
AS (
    SELECT cc.CustomerCategoryName,
    COUNT(GenericCustomerName) AS CustomerCOUNT
    FROM NormalizedCustomers nc
    JOIN Sales.CustomerCategories cc ON nc.CustomerCategoryID = cc.CustomerCategoryID
    GROUP BY cc.CustomerCategoryName
),
TotalCount 
AS (
    SELECT SUM(CustomerCOUNT) AS TotalCustCount FROM CategoryCounts
)
SELECT CustomerCategoryName,CustomerCOUNT,
(SELECT TotalCustCount FROM TotalCount) AS TotalCustCount,
CAST(CustomerCOUNT * 1.0 / (SELECT TotalCustCount FROM TotalCount) AS DECIMAL(10,4)) AS DistributionFactor
FROM CategoryCounts
ORDER BY CustomerCategoryName